// Archivo desactivado - usar useRole.ts en su lugar
export function useRole() {
  throw new Error('useRole.tsx está desactivado - usar useRole.ts');
}