
export interface InvitationRequest {
  email: string;
  companyId: string;
  role: string;
  invitationId?: string;
}
