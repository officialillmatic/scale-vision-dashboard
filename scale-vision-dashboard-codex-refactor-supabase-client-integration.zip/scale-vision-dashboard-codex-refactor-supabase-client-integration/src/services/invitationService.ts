
// Legacy re-export file for backward compatibility
// This ensures existing imports continue to work
export * from './invitation';
