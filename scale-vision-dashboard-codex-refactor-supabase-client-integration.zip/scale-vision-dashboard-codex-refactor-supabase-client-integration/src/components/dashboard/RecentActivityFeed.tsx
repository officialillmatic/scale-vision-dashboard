
import React from 'react';
import { UnifiedRecentActivityFeed } from './UnifiedRecentActivityFeed';

export function RecentActivityFeed() {
  return <UnifiedRecentActivityFeed />;
}
