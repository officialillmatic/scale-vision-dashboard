
import React from "react";
import { WhiteLabelCallsTable } from "./WhiteLabelCallsTable";

export function CallTable() {
  return <WhiteLabelCallsTable />;
}
