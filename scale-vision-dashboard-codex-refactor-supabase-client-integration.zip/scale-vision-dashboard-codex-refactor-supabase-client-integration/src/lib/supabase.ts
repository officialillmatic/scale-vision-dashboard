export * from '@/integrations/supabase/client';
