
import React from 'react';
import { TeamAgentsContainer } from './TeamAgentsContainer';

export function TeamAgents() {
  return <TeamAgentsContainer />;
}
