
import React from "react";
import { ProductionCallsTable } from "./ProductionCallsTable";

export const CallsTable = () => {
  return <ProductionCallsTable />;
};
